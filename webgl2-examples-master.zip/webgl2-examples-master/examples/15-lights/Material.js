export class Material {

    constructor() {
        this.texture = null;
        this.diffuse = 1;
        this.specular = 1;
        this.shininess = 50;
    }

}